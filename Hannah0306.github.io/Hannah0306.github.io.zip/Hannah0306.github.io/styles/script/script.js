
function showMessage()
{
    let age = 15;
    let Name = "Hannah";
     if (age >=18)
     {
        alert("Hello" + Name + "You can how drive :)");
     }
     else
     {
      alert("Hello kid," + "You are too young to drive");
    let years = 18 - age;
      alert("Please come back after"+years+"years")
     }
     let sum = 0;
     for (let i = 0; i<=100; i = i+1)
{
   sum = sum + i;

}
     
alert(sum);
    
}

document.getElementById("main").style.backgroundColor = "grey";